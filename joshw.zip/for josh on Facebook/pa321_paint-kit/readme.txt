============================
Project Airbus - Airbus A321
============================

www.pairbus.com



new antenna hiding method
-------------------------

	Don't hide the antennas using alpha; add 'SATV' to the title string in the 'Aircraft.cfg' for the satcom antenna, and 'ANT2' for the alternate antenna config (sans the inverted commas).



credits
-------

	the PA team: Demetris Themistocleous, Derek Mayer and Alexis Vletsas

	Andy Warden, Peter Binamira, Thomas Ruth, Alessandro Savarese, Gianmarco Bettiol, Alexander Kvitta, Trevor Slack, Nicholas Wu, David Bromwich, Matthey Murray, Manny Osias, Spike Acenas, Mark Bolatete, Kester Masias, Sheldon Fernandes, Tom Collins, Dickson Chan, John Tavendale, Steve McBee



Copyright (c) 2011 Project Airbus

Do not sell or attempt to make profit in any way from any of our work. Do not distribute any of the official packages without our consent. This package can only be made publicly available to be downloaded from our website, www.avsim.com and www.flightsim.com.