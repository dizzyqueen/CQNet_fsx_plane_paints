## COMPUTERQUEEN.NET B777-9X

### SKYSPIRIT2019-777 BOEING 777-9X ... Textures for the CQ.Net Livery
<img src="https://github.com/dizzyqueen/CQNet_fsx_plane_paints/blob/master/CQ_B777-9X/thumbnail.jpg">

Model and Paint Kit developed by the SkySpirit2019-777 Team, and is Freeware.
